class Person:
    def hello(self):
        return 'hello'
